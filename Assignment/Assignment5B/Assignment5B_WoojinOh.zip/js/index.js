// coded by @ChaituVR
const projectName = 'portfolio';
localStorage.setItem('example_project', 'Personal Portfolio');